<?php 

          
   

   
   	if (isset($_POST["submit"])) {
   $crlf = "\r\n";
    //Get Data
    $name = strip_tags($_POST['name']);
    $email = strip_tags($_POST['email']);
    $phone = strip_tags($_POST['tel']);
    $subject = strip_tags($_POST['subject']);
    $message = strip_tags($_POST['message']);

    // Parse/Format/Verify Data
   $from = 'Detailing kontakt forma'; 
   $to = 'info@detailing-star.hr'; 
   $subject = 'Poruka s detailing konatkt forme ';
                
      
   
         //  $message = "$subject $crlf 
	// Ime osobe: $name $crlf 
	// E-Mail kontakta: $email $crlf 
    // Telefone/mobilni: $phone $crlf
    // Poruka / upit : $message";
	
	
	
	 $message = ' 
<html><head></head>
 
    <body>
	<br/>
              <img src="http://detailing-star.hr/assets/template/images/logo.png" alt=""/>
        <div>
          <table style="width: 400px;" border="1">
              
              <tr>
                  <th colspan="2"><h3>Kontakt obrazac s stranice Detailing star</h3></th>
              </tr>
              
              <tr>
                  <td colspan="2"><p><strong>Subjekt : '.$subject.'</strong></p> </td>
                
              </tr>
              
              
              

               <tr>
                  <td>Ime :</td>
                 <td> <p>'.$name.'</p></td>
              </tr>
              
              <tr>
                  <td>tel :</td>
                  <td> <p>'.$phone.'</p></td>
              </tr>
              
                <tr>
                  <td>E-mail :</td>
                  <td>  <p>'.$email.'</p></td>
              </tr>
              
              
            
              <tr>
                  
                  
               <tr><td colspan="2" style="background-color:#F1F1F1; ">
                       
              <table>
                  <tr><td>
                          <p>'.$message.'</p>
                  </td></tr>
               
                      
                 
              </table> 
               </td></tr>
                     
                     
                     
             
             </table>
        </div>
        
    </body>
</html>
';
	 
	 
	 
	


    $headers = 'From: ' . $from  . $crlf .
               'Reply-To: ' . $from  . $crlf .
               'Content-Type: text/html; charset=UTF-8';
	
   
   
   
   
    if (!$_POST['name']) 
   {
   $errName = 'Molimo unesite svoje ime';
     $warning ='<div class="thankyou">Obrazac nije potvrđen, provjerite polja</div>';
   }
   
     if (!$_POST['tel']) 
   {
    $errTel = 'Molimo unesite svoje kontakt broj';
       $warning ='<div class="thankyou">Obrazac nije potvrđen, provjerite polja</div>';
    
   }
   
   
   if (!$_POST['email'] || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) 
           {$errEmail = 'Molimo unjeti valjanu, ispravnu e-mail adresu';
             $warning ='<div class="thankyou">Obrazac nije potvrđen, provjerite polja</div>';
   }
   

           
           
           
      if (!$errName && !$errEmail && !$errMessage) {

	if (  mail($to, $subject, $message, $headers)) {

		$result='<div class="thankyou">Hvala što ste nas kontakirali!</div>';
              
                 echo "<script>alert('Hvala što ste nas kontakirali!');</script>";

	} else {

		$result='<div class="thankyou">Problem s slanjem poruke, pokušajte kasnije!</div>';
                
                

	}

}     
           
           
           
   


    
	
  
    
	
	}
?>




<!DOCTYPE html>
<!--[if lte IE 7 ]> <html class='ie ie7 lt-ie8' lang='en'> <![endif]-->
<!--[if IE 8 ]> <html class='ie ie8 lt-ie8' lang='en'> <![endif]-->
<!--[if IE 9 ]> <html class='ie ie9' lang='en'> <![endif]-->
<!--[if gt IE 9]> <!--><html lang='en'><!-- <![endif]-->
<head><meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="keywords" content="Pranje auta, ispravno pranje, autopraonica, kemijsko čišćenje, nano zaštita, auto detailing, detailing, njega vozila, poliranje vozila, poliranje auta, Detailing Star" />
  <meta name="description" content="">
  <meta name="robots" content="all ">
  <title>Kontakt | Detailing Star | centar za njegu vozila</title>



  <link rel="shortcut icon" href="../assets/template/images/favicon.ico">
  <link href="../assets/template/css/style.css?v=128" media="all" rel="stylesheet">
  <link href="../assets/template/css/mobile.css?v=1" media="all" rel="stylesheet">
  <link href="../assets/template/css/my.css" media="all" rel="stylesheet">
  <!--link rel="stylesheet" href="../backformer/core/themes/default/bf.css" type="text/css"-->
  <!--[if lte IE 8]>
  <link href="../assets/template/css/old-ie.css" media="all" rel="stylesheet">
  <script src="../assets/template/js/css3-mediaqueries.js"></script>
  <![endif]--><!--[if lt IE 9]>
  <script src="../assets/template/js/ie9.js"></script>
  <![endif]-->
 
  <script src="//code.jquery.com/jquery-1.9.1.min.js"></script>
  <script type="text/javascript">
    window.jQuery || document.write("<script src='js/jquery.min.js'>\x3C/script>");
	

  </script>
  

  
  <script src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
  
  <script src="../assets/template/js/jcarousellite.min.js"></script>
  <script src="../assets/template/js/jquery.kwicks.min.js"></script>
  <script src="../assets/template/js/banner.js"></script>
  <script src="../assets/template/js/jquery.fancybox.pack.js"></script>
  <script src="../assets/template/js/pin.js"></script>
  <script src="../assets/template/js/script.js?rand=125"></script>
  <script src="../assets/template/js/lib.js"></script>
  <script src="../assets/template/js/settings.js"></script>
  
  
<script type="text/javascript" src="../assets/components/shopkeeper/js/web/lang/ru.js?v=2.3.4"></script>
<script type="text/javascript" src="../assets/template/js/shop.js?v=2.3.4"></script>


    
    
 <script type="text/javascript" charset="UTF-8" src="http://maps.googleapis.com/maps-api-v3/api/js/28/11/intl/en_gb/stats.js"></script>
    
    
</head>

<body>
  <div id="wrapper">
      
      
      
    <header>
                  <div class="inner">
                     <a class="logo" href="../index.html"><img src="../assets/template/images/logo.png" alt="Detailing Star, centar za njegu vozila"></a>	
                     <div id="callback-form-container">
                        <div id="callback-overlay"></div>
                        <div id="callback-popup">        	<a href="javascript:void(0);" class="close-callback-popup">&times;</a>                        </div>
                     </div>
                     <div class="b-header-contacts">
                        <div class="callback">          	<a href="" class="open_callback_form">Webshop</a>         </div>
                        <div class="contact-item">		<span class="phone">01 4852 449</span>	  </div>
                        <div class="contact-item">			  </div>
                     </div>
                     <nav class="b-header-nav">
                        <ul>
                           <li  class="nav-item first active"><a href="">Naslovna</a></li>
                           <li  class="nav-item "><a href="about.html">O nama</a></li>
                           <li  class="nav-item"><a href="services.html" >Usluge</a></li>
                           <li  class="nav-item"><a href="catalog.html" >Webshop</a></li>
                           <li  class="nav-item"><a href="Galerija/gallery.php" >Galerija radova</a></li>
                           <li  class="nav-item"><a href="Training.html">Obuka</a></li>
                           <li  class="nav-item"><a href="partners.html" >Partneri</a></li>
                           <li  class="nav-item"><a href="prices.html" >Cjenik</a></li>
                           <li  class="nav-item last"><a href="Kontakt/Kontakt.php" >Kontakt</a></li>
                        </ul>
                        <div class="mobile-nav-close mobile-only"></div>
                     </nav>
                     <nav class="b-header-mobile-menu" style="display:none">
                        <div class="mobile-menu">
                           <a href="Kontakt/kontakt.php" title="Kontakt">
                              <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"viewBox="0 0 20 20" enable-background="new 0 0 20 20" xml:space="preserve">
                                 <g>
                                    <path fill="#141515" d="M10,10.953c-2.239,0-4.061-1.821-4.061-4.06S7.761,2.833,10,2.833s4.061,1.821,4.061,4.06 S12.239,10.953,10,10.953z M10,4.233c-1.467,0-2.66,1.193-2.66,2.66s1.193,2.66,2.66,2.66s2.66-1.193,2.66-2.66	S11.467,4.233,10,4.233z"/>
                                    <path fill="#141515" d="M10,19.801l-0.545-0.675c-2.669-3.306-6.218-8.17-6.218-12.233C3.237,3.164,6.271,0.13,10,0.13	s6.763,3.034,6.763,6.763c0,4.069-3.549,8.93-6.218,12.234L10,19.801z M10,1.531c-2.957,0-5.362,2.405-5.362,5.362 c0,3.366,2.915,7.574,5.362,10.672c2.448-3.096,5.362-7.302,5.362-10.672C15.362,3.936,12.957,1.531,10,1.531z"/>
                                 </g>
                              </svg>
                           </a>
                           <a href="tel:+1 4852 449" title="Telefon">
                              <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 20 20" enable-background="new 0 0 20 20" xml:space="preserve">
                                 <g>
                                    <path fill="#141515" d="M14.746,19.933c-3.122,0-6.896-2.61-9.481-5.197c-3.101-3.1-6.235-7.908-4.866-11.252l0.053-0.13 L3.732,0.07l5.569,5.57l-2.373,2.37c0.907,1.958,3.104,4.155,5.062,5.062l2.37-2.37l5.57,5.566l-3.283,3.281l-0.13,0.053 C15.963,19.829,15.367,19.933,14.746,19.933z M1.646,4.137c-0.767,2.187,1.105,6.106,4.607,9.609 c3.503,3.503,7.425,5.372,9.609,4.607l2.087-2.086l-3.59-3.587l-2.03,2.031l-0.423-0.158c-2.591-0.972-5.489-3.87-6.461-6.462 L5.288,7.669l2.033-2.031L3.732,2.05L1.646,4.137z"/>
                                 </g>
                              </svg>
                           </a>
                           <a href="" title="webshop">
                              <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 20 20" enable-background="new 0 0 20 20" xml:space="preserve">
                                 <g>
                                    <polygon fill="#141515" points="17.502,15.164 5.871,15.164 2.39,2.175 0.285,2.175 0.285,0.774 3.464,0.774 6.945,13.764 17.502,13.764"/>
                                    <path fill="#141515" d="M17.503,12.552H7.852L5.478,3.687h14.399L17.503,12.552z M8.926,11.151h7.503l1.624-6.064H7.302 L8.926,11.151z"/>
                                    <path fill="#141515" d="M7.885,19.226c-0.919,0-1.666-0.746-1.666-1.663s0.747-1.664,1.666-1.664c0.917,0,1.664,0.747,1.664,1.664 S8.802,19.226,7.885,19.226z M7.885,17.299c-0.146,0-0.266,0.118-0.266,0.264c-0.001,0.287,0.528,0.29,0.529,0 C8.148,17.417,8.03,17.299,7.885,17.299z"/>
                                    <path fill="#141515" d="M16.004,19.226c-0.917,0-1.664-0.746-1.664-1.663s0.747-1.664,1.664-1.664s1.663,0.747,1.663,1.664 S16.921,19.226,16.004,19.226z M16.004,17.299c-0.146,0-0.264,0.118-0.264,0.264c0,0.286,0.526,0.287,0.526,0 C16.267,17.417,16.148,17.299,16.004,17.299z"/>
                                 </g>
                              </svg>
                           </a>
                           <a title="Meni" class="mobile-menu-toggle">
                              <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 20 20" enable-background="new 0 0 20 20" xml:space="preserve">
                                 <g>
                                    <rect y="2.305" width="20" height="1.4"/>
                                    <rect y="9.3" width="20" height="1.4"/>
                                    <rect y="16.295" width="20" height="1.4"/>
                                 </g>
                              </svg>
                           </a>
                        </div>
                     </nav>
                  </div>
               </header>
      
      
      
      

<div class="b-top-banners map">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2780.957707963465!2d15.864984515830596!3d45.8121053791066!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4765d1a2f452a1a5%3A0xd5165c751ae991c3!2sSamoborska+cesta+226%2C+10000%2C+Zagreb!5e0!3m2!1sen!2shr!4v1493283988095" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
      <div class="inner"> 
     <div style="text-align: center; width: 50%; padding-bottom: 10px;">
       <?php echo "<h1 class='errorForm'>$warning</h1>";?>
     </div>
      </div>
    </div>
 
    
    <div class="main">
      <div class="inner">
        <div class="to-top">
          <a>Na Vrh</a>
        </div>

           
     
           <aside class="leftside">

<div class="leftside-sticky">
 <div class="b-main-nav clr"><div class="main-nav-col">

<a class="main-nav-title"><span>Eksterijer</span></a>
<ul class="main-nav-list">
    

 <li class="main-nav-item">

	<a href="../Eksterijer/nano-titanska-zastita.php">Nano Titanska zaštita KRYTEX</a>

</li>       


 <li class="main-nav-item">
	<a href="../Eksterijer/kompozitna-zastita.php">Kompozitna zaštita KRYTEX</a>

</li>





<li class="main-nav-item">
	<a href="../Eksterijer/nano-keramicka-zastita.php">Nano keramička zaštita KRYTEX</a>

</li>





 <li class="main-nav-item">
	<a href="../Eksterijer/zastita-tekuce-staklo.php">Zaštita "Tekuće Staklo" KRYTEX</a>   
</li>





 <li class="main-nav-item">
	<a href="../Eksterijer/polimerna-zastita-mega-quick.php">Polimerna zaštita Mega Quick</a>   
</li>



<li class="main-nav-item">
<a href="../Eksterijer/poliranje-vozila.php">Poliranje vozila</a>

</li>



<li class="main-nav-item">
	<a href="../Eksterijer/zastita-folijom-SunTek.php">Zaštita folijom SunTek</a>       
</li>



<li class="main-nav-item">
	<a href="../Eksterijer/uklanjanje-ogrebotina.php">Uklanjanje ogrebotina</a>
</li>



<li class="main-nav-item">
	<a href="../Eksterijer/lakiranje-auta.php">Lakiranje auta</a>
</li>

</ul>

</div>

<div class="main-nav-col">

	<a class="main-nav-title"><span>Interijer</span></a>

	<ul class="main-nav-list">
            
            
<li class="main-nav-item">
<a href="../Interijer/kemijsko-ciscenje-interjera.php">Kemijsko čišćenje interjera</a>
</li>

<li class="main-nav-item">
	<a href="../Interijer/nano-zastita-krytex.php">Nano zaštita KRYTEX</a>
</li>

<li class="main-nav-item">
	<a href="../Interijer/antibakterijska-obrada.php">Antibakterijska obrada klime i ventilacije</a>
</li>

<li class="main-nav-item">
	<a href="../Interijer/unistavanje-losih-mirisa-ozonom.php">Uništavanje loših mirisa ozonom</a>
</li>


<li class="main-nav-item">
<a href="../Interijer/aromatizacija-interijera-auta.php">Aromatizacija interijera auta</a>
</li>

</ul>

</div>

<div class="main-nav-col">

	<a class="main-nav-title"><span>Autostakla</span></a>

	<ul class="main-nav-list">
            
<li class="main-nav-item">
<a href="../Autostakla/nano-zastita-stakala.php">Nano zaštita stakala</a>
</li>



<li class="main-nav-item">
	<a href="../Autostakla/poliranje-farova.php">Poliranje farova</a>
</li>



<li class="main-nav-item">
<a href="../Autostakla/zastita-farova-od-ostecenja.php">Zaštita farova od oštećenja</a>
</li>




<li class="main-nav-item">
	<a href="../Autostakla/toniranje-stakala.php">Toniranje stakala</a>
</li>

<li class="main-nav-item">
	<a href="../Autostakla/anti-termalna-zastita-stakla-folijom-SunTek.php">Anti termalna zaštita stakla folijom SunTek</a>
</li>

</ul>

</div>

<div class="main-nav-col">

	<a class="main-nav-title"><span>Felge</span></a>

	<ul class="main-nav-list">
            
            
     <li class="main-nav-item">
<a href="../Felge/kemijsko-ciscenje-felga.php">Kemijsko čišćenje felga</a>
</li>


 <li class="main-nav-item">
<a href="../Felge/nano-zastita-felga.php">Nano zaštita felga</a>
</li>


<li class="main-nav-item">
<a href="../Felge/nano-zastita-guma.php">Nano zaštita guma</a>
</li>


</ul>

</div>

</div>







           <div class="b-main-recommends">
                        <div class="main-recommends-col">
                           <a class="main-recommends-title" href="../IspravnoPranje.html">Ispravno pranje</a>
                           <div class="main-recommends-description">Kako oprati automobil, a da ga ne oštetite!</div>
                        </div>
                        <div class="main-recommends-col">
                           <a class="main-recommends-title" href="../Detailing-brodova.html" >Terenski detailing</a>
                           <div class="main-recommends-description">Paket usluga na Vašoj lokaciji!</div>
                        </div>
                        <div class="main-recommends-col">
                           <a class="main-recommends-title" href="../Oprema-za-detailing.html" >Oprema za detailing</a>
                           <div class="main-recommends-description">Profesionalna sredstva za njegu vozila!</div>
                        </div>
                     </div>





          </div>

        </aside> 
          
          
          
          
          
        <div class="content">
<div class="wrap-h1 wrap-h1-product">
 <div class="inner">
        <h1>
          <span>Kontakt</span>
        </h1>
 </div>
</div>
<ul class="B_crumbBox"><li class="B_firstCrumb" itemscope="itemscope" itemtype="http://data-vocabulary.org/Breadcrumb">
        <a class="B_homeCrumb" itemprop="url" rel="Home" href="index.html"><span itemprop="title">Naslovna</span></a></li>
  <li class="B_lastCrumb" itemscope="itemscope" itemtype="http://data-vocabulary.org/Breadcrumb">
  <li itemscope="itemscope" class="B_currentCrumb" itemtype="http://data-vocabulary.org/Breadcrumb">Kontakt</li>
</ul>
            
            
            
            
            
<div class="b-contacts">
<div class="contact-info"><dl><dt>Naša adresa:</dt><dd><address>Samoborska cesta 226, Zagreb</address></dd><dt>Kontakt brojevi:</dt><dd>
<div class="phone"><span>01 4852 449</span></div>

</dd><dt>E-mail:</dt><dd><a href="mailto:info@detailing-star.hr">info@detailing-star.hr</a></dd><dt>Radno vrijeme:</dt><dd>Ponedeljak - petak 9.00-19.00<br />Subota 10.00-19.00</dd><dd></dd><dt></dt></dl><dl><dt>Реквизиты компании:</dt><dd>ООО «Эдванс Стар»<br /><span style="line-height: 1.5em;">ИНН 7714877978<br /></span><span style="line-height: 1.5em;">КПП 771401001 <br /></span><span style="line-height: 1.5em;">ОГРН 1127746529745</span></dd><dd><dl><dd></dd><dd></dd></dl></dd></dl></div>
<div class="contact-form">
<a name="anchor_link"></a>



<form  method="post" id="contactForm" role="form" action="Kontakt.php">
	<input type="hidden" name="nospam:blank" value="" />
      <h2>
       Kontaktirajte nas
      </h2>
      <div class="form-item">
        <label class="form-label">Ime :</label>
        <div class="controls">
          <input class="form-text" type="text" name="name" placeholder="ime" value="<?php echo htmlspecialchars($_POST['name']); ?>" oninvalid="this.setCustomValidity('Molimo Vas uneste svoje ime');">
		  		<?php echo "<p class='errorForm'>$errName</p>";?>
        </div>
      </div>
      <div class="form-item">
        <label class="form-label">Tel:</label>
        <div class="controls">
          <input class="form-text" type="tel" name="tel" placeholder="Tel" value="<?php echo htmlspecialchars($_POST['tel']); ?>" oninvalid="this.setCustomValidity('Molimo Vas uneste svoj kontakt mobitel ili telefon')">
		    	<?php echo "<p class='errorForm'> $errTel</p>";?>
        </div>
      </div>
      <div class="form-item">
        <label class="form-label">E-mail:</label>
        <div class="controls">
          <input class="form-text" type="email" name="email"  placeholder="E-Mail" value="<?php echo htmlspecialchars($_POST['email']); ?>" oninvalid="this.setCustomValidity('Molimo Vas uneste svoj e-mail')">
		  	<?php echo "<p class='errorForm'>$errEmail</p>";?>
        </div>
      </div>
      <div class="form-item">
        <label class="form-label">Poruka:</label>
        <div class="controls">
          <textarea class="form-textarea" name="message" placeholder="Poruka"><?php echo htmlspecialchars($_POST['message']);?></textarea>
		  	<?php echo "<p class='errorForm'>$errMessage</p>";?>
        </div>
      </div>
	  

      <div class="form-item">
        <label class="form-label"></label>
        <div class="controls">
          <button class="btn"  id="submit" name="submit" type="submit" value="Send" onClick="clearform();"><span>Pošalji!</span></button>
        </div>
      </div>
	 
	<?php echo $result; ?>
	  		
    </form></div>
		  </div>
        </div>
      </div>
    </div>
  </div>




    
		

       <!--footer-->  

  <footer> <div class="inner">

      <div class="footer-top">

        <div class="b-footer-socials" style="visibility: hidden;">

 <a class="social-link facebook" href="#"></a><a class="social-link youtube" href="#"></a><a class="social-link instagram" href="#"></a>

        </div>

        <nav class="b-footer-nav">

 <ul>

                

                <li  class="nav-item first">

	<a href="../Onama.html">O nama</a>



</li>

<li  class="nav-item">

	<a href="../Usluge.html" >Usluge</a>

</li>

<li  class="nav-item">

	<a href="../catalog.html" >Webshop</a>

</li>

<li  class="nav-item">

	<a href="../Galerija/gallery.html" >Galerija radova</a>

</li>

<li  class="nav-item">

	<a href="../Obuka.html" >Obuka</a>

</li>

<li  class="nav-item">

	<a href="../Partneri.html" >Partneri</a>

</li>

<li  class="nav-item">

	<a href="../Cijene.html" >Cjenik</a>

</li>

<li  class="nav-item">

    <a href="../Kontakt/Kontakt.php" >Kontakt</a>

</li>



</ul>

        

        </nav>

      </div>

      <div class="footer-bottom">

	  	<div class="b-footer-contacts">

	  		<div style="width: 50%; display: inline-block;">

					<div class="b-footer-contacts-row">Zagreb, Samoborska 226</div>

					<div class="b-footer-contacts-row"><span>Tel.:</span> +385 1 4852 449 <span>|</span> <a href="mailto: info@detailing-star.hr">info@detailing-star.hr</a></div>

					<div class="b-footer-contacts-row">© 2017 «Detailing Star» <span></span> 

			</div>



		</div>

      </div>

    </div>



<div style="visibility: hidden;"><a href="http://sfera-adria.com" >Sfera-Adria.com</a></div>

      </div>

  </footer>  
	
	
 
    
      <script type="text/javascript">
	      $(document).ready(function(){
			  
			
				   $('submit').on('click', function(){
					    $(this).closest('form')[0].reset();
				   });
			 		 
			  
			
			  
			  });

   
  </script>
    
    
  
</body>
</html>